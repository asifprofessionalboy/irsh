﻿using Dapper;
using LOG_INNOVATION.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace LOG_INNOVATION.Controllers
{
    public class GeoController : Controller
    {
        private readonly IConfiguration configuration;

        public GeoController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        private string GetConnectionString()
        {
            return this.configuration.GetConnectionString("InnovationCS");
        }

        [Authorize]
        public IActionResult GeoFencing()
        {
            var session = HttpContext.Request.Cookies["Session"];
            var UserName = HttpContext.Request.Cookies["UserName"];

            //if (!string.IsNullOrEmpty(session) && !string.IsNullOrEmpty(UserName))
            //{
                var data = GetLocations();
                return View();
            //}
            //else
            //{
            //    return RedirectToAction("Login", "User");
            //}
            
        }


        public IActionResult GetLocations()
        {
           
                var UserId = HttpContext.Request.Cookies["Session"];
                string connectionString = GetConnectionString();
                string query = @"select ps.Worksite from INNOVATIONDB.DBO.App_Position_Worksite as ps 
                                inner join INNOVATIONDB.DBO.App_Emp_position as es on es.position = ps.position 
                                where es.Pno = '" + UserId + "'";

                using (var connection = new SqlConnection(connectionString))
                {
                    string locations = connection.QuerySingleOrDefault<string>(query);

                    string s = locations;
                    s = "'" + s;

                    s = s.Replace(",", "','");
                    s = s + "'";

                    string query2 = @"select Longitude,Latitude from INNOVATIONDB.DBO.App_LocationMaster 
                                      where worksite in (" + s + ")";

                    
                var locations2 = connection.Query<WorkLocation>(query2).ToList();
                    List<string> locations2List = new List<string>();

                    foreach (var arr2 in locations2)
                    {
                        locations2List.Add(arr2.Latitude.ToString());
                        locations2List.Add(arr2.Longitude.ToString());
                       

                    }
                ViewBag.PolyData = locations2List;
                    return View(locations2List);
                }
            
           
        }



        //public IActionResult HardCodeData()
        //{

        //    var polygons = new List<List<Dictionary<string, double>>>
        //    {
        //        new List<Dictionary<string, double>>
        //        {
        //            //new Dictionary<string, double>{{"latitude", 22.798088 }, { "longitude", 86.184976 } },
        //            //new Dictionary<string, double>{{"latitude", 22.796404 }, { "longitude", 86.184595 } },
        //            //new Dictionary<string, double>{{"latitude", 22.796364 }, { "longitude", 86.183014 } },
        //            //new Dictionary<string, double>{{"latitude", 22.797673 }, { "longitude", 86.182989 } },
        //            //new Dictionary<string, double>{{"latitude", 22.797986 }, { "longitude", 86.183358 } }

        //            new Dictionary<string, double>{{"latitude", 22.804431 }, { "longitude", 86.183302 } },
        //            new Dictionary<string, double>{{"latitude", 22.804145 }, { "longitude", 86.183529 } },
        //            new Dictionary<string, double>{{"latitude", 22.804407 }, { "longitude", 86.183932 } },
        //            new Dictionary<string, double>{{"latitude", 22.804583 }, { "longitude", 86.183633 } }
                    

        //        }
        //    };
        //    ViewBag.PolyData = polygons;
        //    return View();
        //}

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("Session");
            return RedirectToAction("Login", "User");

        }




        [HttpPost]
        public IActionResult DataSaved()
        {
            return RedirectToAction("Login", "User");
        }

    }
}
